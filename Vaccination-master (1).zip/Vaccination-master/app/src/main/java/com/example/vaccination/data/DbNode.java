package com.example.vaccination.data;

public enum DbNode {
    ADMIN, USER, HOSPITAL, VACCINE, HISTORY, REQUEST,RECORD, INDEX, COUNTER;
}

