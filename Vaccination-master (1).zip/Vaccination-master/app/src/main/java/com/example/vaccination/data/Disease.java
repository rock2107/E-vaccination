package com.example.vaccination.data;

public enum Disease {
    POLIO, MEASLES, FLU, COVID, CHICKENPOX, MALARIA, DENGUE, DIARRHEA,ALL;
}
