package com.example.vaccination.data;

public enum HospitalCollection {
    vaccineList, requestList, recordList
}
