package com.example.vaccination.data;

public enum UserType {
    Admin,User,Hospital;
}
