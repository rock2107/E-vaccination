package com.example.vaccination.data;

public enum VaccineStatus {
    COMPLETED,DENIED,CANCELLED,APPROVED,WAITING;
}
