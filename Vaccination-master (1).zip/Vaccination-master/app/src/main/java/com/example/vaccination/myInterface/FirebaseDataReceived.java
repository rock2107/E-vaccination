package com.example.vaccination.myInterface;

public interface FirebaseDataReceived {
    void dataReceived(Object object, boolean success);
}
