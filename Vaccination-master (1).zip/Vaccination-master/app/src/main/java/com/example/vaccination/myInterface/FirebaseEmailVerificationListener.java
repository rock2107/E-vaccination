package com.example.vaccination.myInterface;

public interface FirebaseEmailVerificationListener {
    void onResult(boolean success);
}
