package com.example.vaccination.myInterface;

public interface MyFirebaseAuthorizationCallback {
    void isAuthorised(Boolean result,boolean profileSetup);

}
