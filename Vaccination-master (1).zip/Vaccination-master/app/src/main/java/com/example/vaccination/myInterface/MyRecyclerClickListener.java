package com.example.vaccination.myInterface;

public interface MyRecyclerClickListener {
    void onClick(int position);
}
