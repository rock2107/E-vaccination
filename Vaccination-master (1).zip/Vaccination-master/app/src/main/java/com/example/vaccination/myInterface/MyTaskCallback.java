package com.example.vaccination.myInterface;

public interface MyTaskCallback {
    void result(boolean taskSuccess);
}
