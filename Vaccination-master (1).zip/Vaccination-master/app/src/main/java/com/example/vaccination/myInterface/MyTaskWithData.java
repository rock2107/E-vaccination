package com.example.vaccination.myInterface;

public interface MyTaskWithData {
    void result(boolean taskSuccess,String data);
}
