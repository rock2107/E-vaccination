package com.example.vaccination.myInterface;

import android.view.View;

public interface RecyclerLongClickListener {
    void onclick(int position, View view);
}
