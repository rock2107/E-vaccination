package com.example.vaccination.myInterface;

public interface TaskCallbackMessage {
    void result(boolean taskStatus, String taskMessage);
}
