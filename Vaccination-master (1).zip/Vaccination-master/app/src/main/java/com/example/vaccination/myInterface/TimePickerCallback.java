package com.example.vaccination.myInterface;

public interface TimePickerCallback {
    void setTime(String time);
}
