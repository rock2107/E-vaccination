package com.example.vaccination.ui.authentication.forgotpassword;

import androidx.lifecycle.ViewModel;

public class ForgotPasswordViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}