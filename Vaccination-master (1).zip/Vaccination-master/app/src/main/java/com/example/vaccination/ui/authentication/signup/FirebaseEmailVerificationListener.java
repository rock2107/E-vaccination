package com.example.vaccination.ui.authentication.signup;

public interface FirebaseEmailVerificationListener {
    void onResult(boolean successful);
}
